package kr.co.fishbang.profile.controller;

public class ThumbnailController {
//섬네일 다운로드 
}
