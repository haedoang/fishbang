package kr.co.fishbang.repository.mapper;

public interface CompetitionMapper {

}
