package kr.co.fishbang.comment.controller;

public class 게시글댓글 {

}
