package kr.co.fishbang.profile.controller;

public class ProfileController {
//프로필 다운로드 
	
}
