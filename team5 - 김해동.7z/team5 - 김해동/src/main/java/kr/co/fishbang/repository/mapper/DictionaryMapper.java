package kr.co.fishbang.repository.mapper;

import java.util.List;

import kr.co.fishbang.repository.domain.Dictionary;

public interface DictionaryMapper {
		public List<Dictionary> selectDictionary1();
		public List<Dictionary> selectDictionary2();
		public List<Dictionary> selectDictionary3();
		public List<Dictionary> selectDictionary4();
		public List<Dictionary> selectDictionary5();
		public List<Dictionary> selectDictionary6();
		public List<Dictionary> selectDictionary7();
		public List<Dictionary> selectDictionary8();
		public List<Dictionary> selectDictionary9();
		public List<Dictionary> selectDictionary10();
		public List<Dictionary> selectDictionary11();
		public List<Dictionary> selectDictionary12();
		public List<Dictionary> selectDictionary13();
		public List<Dictionary> selectDictionary14();
		public List<Dictionary> selectDictionary15();
		public List<Dictionary> selectDictionary16();
		public List<Dictionary> selectDictionary17();
		public List<Dictionary> selectDictionary18();
		public List<Dictionary> selectDictionary19();
		public List<Dictionary> selectDictionary20();
		public List<Dictionary> selectDictionary21();
		public List<Dictionary> selectDictionary22();
		public List<Dictionary> selectDictionary23();
		public List<Dictionary> selectDictionary24();
		public List<Dictionary> selectDictionary(int no1, int no2);
		

	}


