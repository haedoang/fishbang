package kr.co.fishbang.common.file;

public class 첨부파일저장 {

}
